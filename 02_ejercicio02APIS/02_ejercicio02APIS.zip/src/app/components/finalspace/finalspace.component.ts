import {Component, OnInit} from '@angular/core';
import {FinalSpace} from "../../common/interfaceFinalSpace";
import {FinalspaceService} from "../../services/finalspace.service";

@Component({
  selector: 'app-finalspace',
  templateUrl: './finalspace.component.html',
  styleUrls: ['./finalspace.component.css']
})
export class FinalspaceComponent implements OnInit{

  dataApi!: FinalSpace[];

  constructor(private fsservice: FinalspaceService) {

  }

  ngOnInit(): void {
    this.loadCharacters();
  }

  private loadCharacters() {
    this.fsservice.getCharacters().subscribe(
        {
          // La respuesta del servidor la cogemos con el next
          // El next es si va todo bien
          next: (datos: FinalSpace[]) => {
            this.dataApi = datos;
            console.log(datos);

          },
          // El error si algo sale mal
          error: (err) => {
            alert(err.message);
          },
          // Aquí si todo ha salido bien
          complete: () => {
            console.log('Done');
          }
        }
    )
  }

}
