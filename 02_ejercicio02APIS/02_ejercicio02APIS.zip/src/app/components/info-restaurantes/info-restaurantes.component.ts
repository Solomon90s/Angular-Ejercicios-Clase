import { Component } from '@angular/core';

@Component({
  selector: 'app-info-restaurantes',
  templateUrl: './info-restaurantes.component.html',
  styleUrls: ['./info-restaurantes.component.css']
})
export class InfoRestaurantesComponent {

}
