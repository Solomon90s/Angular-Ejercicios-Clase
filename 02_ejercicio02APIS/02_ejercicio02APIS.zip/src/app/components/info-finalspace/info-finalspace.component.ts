import {Component, OnInit} from '@angular/core';
import {FinalSpace} from "../../common/interfaceFinalSpace";
import {ActivatedRoute, Router} from "@angular/router";
import {FinalspaceService} from "../../services/finalspace.service";

@Component({
  selector: 'app-info-finalspace',
  templateUrl: './info-finalspace.component.html',
  styleUrls: ['./info-finalspace.component.css']
})
export class InfoFinalspaceComponent implements OnInit{

  // Creamos una variable del id del personaje
  idChar: number = 0;

  // Recogemos el personaje
  char!: FinalSpace;

  title = 'Api Final Space con Angular';

  // Recogemos el valor
  constructor(private activatedRoute: ActivatedRoute,
              private dataService: FinalspaceService,
              private router: Router) {
    // Nos permite acceder a las variables de la ruta
  }

  ngOnInit(): void {
      this.loadChar();
    }

  private loadChar() {

    // Esta es la manera dinámica
    this.activatedRoute.params.subscribe({
      next: value => {
        console.log(value);
        this.idChar = +value['id'];
        this.dataService.getCharacter(this.idChar).subscribe({
          next: charData => {
            this.char = charData;
          },
          error: err => {
            console.error(err);
          },
          complete: () => {
            console.log('Char loaded');
          }
        })
      },
      error: err => {
        console.error(err);
      },
      complete: () => {
        console.log('Done');
      }
    });
    console.log(this.activatedRoute.snapshot.params);
  }

  anterior() {
    if (this.idChar > 0) this.router.navigateByUrl('/info-finalspace/'+(this.idChar-1));
  }

  siguiente() {
    if (this.idChar < 47)this.router.navigateByUrl('/info-finalspace/'+(this.idChar+1));
  }
}
