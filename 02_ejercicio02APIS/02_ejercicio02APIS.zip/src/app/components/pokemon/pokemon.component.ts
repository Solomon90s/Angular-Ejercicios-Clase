import {Component, OnInit} from '@angular/core';
import {ApiResultPokemon} from "../../common/interfacePokemon";
import {PokemonService} from "../../services/pokemon.service";

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit{
  dataApi!: ApiResultPokemon;

  // Creamos la variable de la página actual, que empieza en la 1. Es la pagina inicial
  page: number = 1;

  constructor(private pkmservice: PokemonService) {

  }
  ngOnInit(): void {

    this.loadCharacters();
  }

  loadCharacters() {
    this.pkmservice.getCharactersPagination(this.page).subscribe(
      {
        // La respuesta del servidor la cogemos con el next
        // El next es si va todo bien
        next: (datos: ApiResultPokemon) => {
          this.dataApi = datos;
          console.log(datos);

        },
        // El error si algo sale mal
        error: (err) => {
          alert(err.message);
        },
        // Aquí si todo ha salido bien
        complete: () => {
          console.log('Done');
        }
      }
    )
  }

}
