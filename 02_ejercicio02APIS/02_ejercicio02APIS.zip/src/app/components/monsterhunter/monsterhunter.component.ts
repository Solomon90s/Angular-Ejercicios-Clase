import {Component, OnInit} from '@angular/core';
import {WeaponsMonsterHunter} from "../../common/interfaceMonsterHunter";
import {MonsterhunterService} from "../../services/monsterhunter.service";

@Component({
  selector: 'app-monsterhunter',
  templateUrl: './monsterhunter.component.html',
  styleUrls: ['./monsterhunter.component.css']
})
export class MonsterhunterComponent implements OnInit{

  dataApi!: WeaponsMonsterHunter[];

  constructor(private monsterhunterservice: MonsterhunterService) {


  }
  ngOnInit(): void {
    this.loadWeapons();
  }

  private loadWeapons() {
    this.monsterhunterservice.getWeapons().subscribe(
      {
        // La respuesta del servidor la cogemos con el next
        // El next es si va todo bien
        next: (datos: WeaponsMonsterHunter[]) => {
          this.dataApi = datos;
          console.log(datos);

        },
        // El error si algo sale mal
        error: (err) => {
          alert(err.message);
        },
        // Aquí si todo ha salido bien
        complete: () => {
          console.log('Done');
        }
      }
    )
  }
}
