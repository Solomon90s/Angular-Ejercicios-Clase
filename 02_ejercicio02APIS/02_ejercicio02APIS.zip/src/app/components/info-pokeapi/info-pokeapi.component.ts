import { Component } from '@angular/core';

@Component({
  selector: 'app-info-pokeapi',
  templateUrl: './info-pokeapi.component.html',
  styleUrls: ['./info-pokeapi.component.css']
})
export class InfoPokeapiComponent {

}
