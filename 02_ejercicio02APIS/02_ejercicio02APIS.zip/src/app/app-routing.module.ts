import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {InicioComponent} from "./components/inicio/inicio.component";
import {ErrorComponent} from "./components/error/error.component";
import {InfoComponent} from "./components/info/info.component";
import {MonsterhunterComponent} from "./components/monsterhunter/monsterhunter.component";
import {PokemonComponent} from "./components/pokemon/pokemon.component";
import {FinalspaceComponent} from "./components/finalspace/finalspace.component";
import {InfoValorantComponent} from "./components/info-valorant/info-valorant.component";
import {InfoMonsterComponent} from "./components/info-monster/info-monster.component";
import {InfoPokemonComponent} from "./components/info-pokemon/info-pokemon.component";
import {InfoFinalspaceComponent} from "./components/info-finalspace/info-finalspace.component";
import {PokeapiComponent} from "./components/pokeapi/pokeapi.component";
import {RestaurantesComponent} from "./components/restaurantes/restaurantes.component";
import {InfoPokeapiComponent} from "./components/info-pokeapi/info-pokeapi.component";
import {InfoRestaurantesComponent} from "./components/info-restaurantes/info-restaurantes.component";

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/inicio'
  },
  {
    path: 'inicio',
    component:InicioComponent
  },
  {
    path: 'info',
    component: InfoComponent
  },
  {
    path: 'monsterhunter',
    component: MonsterhunterComponent
  },
  {
    path: 'pokemon',
    component: PokemonComponent
  },
  {
    path: 'finalspace',
    component: FinalspaceComponent
  },
  {
    path: 'pokeapi',
    component: PokeapiComponent
  },
  {
    path: 'restaurantes',
    component: RestaurantesComponent
  },
  {
    path: 'info-valorant/:id',
    component: InfoValorantComponent
  },
  {
    path: 'info-monster/:id',
    component: InfoMonsterComponent
  },
  {
    path: 'info-pokemon/:id',
    component: InfoPokemonComponent
  },
  {
    path: 'info-finalspace/:id',
    component: InfoFinalspaceComponent
  },
  {
    path: 'info-pokeapi/:id',
    component: InfoPokeapiComponent
  },
  {
    path: 'info-restaurantes/:id',
    component: InfoRestaurantesComponent
  },
  {
    path: '**',
    component: ErrorComponent,
    pathMatch: "full"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
