import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {FinalSpace} from "../common/interfaceFinalSpace";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class FinalspaceService {

  private URI: string = "https://finalspaceapi.com/api/v0/character/";

  constructor(private http: HttpClient) { }


  getCharacters(): Observable<FinalSpace[]>{
    return this.http.get<FinalSpace[]>(this.URI);
  }

  getCharacter(id:number): Observable<FinalSpace>{
    return this.http.get<FinalSpace>(this.URI+id);
  }


}
