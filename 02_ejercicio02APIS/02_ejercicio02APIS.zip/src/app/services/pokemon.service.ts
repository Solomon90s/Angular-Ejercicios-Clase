import { Injectable } from '@angular/core';
import {Observable} from "rxjs";
import {ApiResultOnePokemon, ApiResultPokemon} from "../common/interfacePokemon";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class PokemonService {

  private URI: string = "https://api.pokemontcg.io/v2/cards/";

  constructor(private http: HttpClient) { }

  getCharacters(): Observable<ApiResultPokemon>{
    return this.http.get<ApiResultPokemon>(this.URI+'?page=1&pageSize=20');
  }
  // Creamos la funcion en la que nos pasan la pagina
  getCharactersPagination(page: number): Observable<ApiResultPokemon>{
    return this.http.get<ApiResultPokemon>(this.URI+'?page=1'+page);
  }

  // Creamos una función pasandole el id del pokemon
  getPokemon(id:string): Observable<ApiResultOnePokemon>{
    return this.http.get<ApiResultOnePokemon>(this.URI+'/'+id);
  }

}
