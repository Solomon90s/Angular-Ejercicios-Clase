import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {WeaponsMonsterHunter} from "../common/interfaceMonsterHunter";

@Injectable({
  providedIn: 'root'
})
export class MonsterhunterService{
private URI: string = 'https://mhw-db.com/weapons';
  constructor(private http: HttpClient) { }

  page: number = 1;

  getWeapons(): Observable<WeaponsMonsterHunter[]> {
    return this.http.get<WeaponsMonsterHunter[]>(this.URI+'?q={"id":{"$gte":1,"$lte":20}}');
  }

  // Creamos una función pasandole el id del arma
  getWeapon(id:number):Observable<WeaponsMonsterHunter> {
    return this.http.get<WeaponsMonsterHunter>(this.URI+'/'+id);
  }


}
