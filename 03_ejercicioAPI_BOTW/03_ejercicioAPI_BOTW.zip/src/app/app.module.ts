import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InicioComponent } from './components/inicio/inicio.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MonstruosComponent } from './components/monstruos/monstruos.component';
import { DetailMonstruosComponent } from './components/detail-monstruos/detail-monstruos.component';
import { ErrorComponent } from './components/error/error.component';
import { FooterComponent } from './components/footer/footer.component';
import {HttpClientModule} from "@angular/common/http";
import { CriaturasComponent } from './components/criaturas/criaturas.component';
import { MaterialesComponent } from './components/materiales/materiales.component';
import { EquipamientoComponent } from './components/equipamiento/equipamiento.component';
import { TesorosComponent } from './components/tesoros/tesoros.component';
import { DetailCritaturasComponent } from './components/detail-critaturas/detail-critaturas.component';
import { DetailEquipamientoComponent } from './components/detail-equipamiento/detail-equipamiento.component';
import { DetailMaterialesComponent } from './components/detail-materiales/detail-materiales.component';
import { DetailTesorosComponent } from './components/detail-tesoros/detail-tesoros.component';

@NgModule({
  declarations: [
    AppComponent,
    InicioComponent,
    NavbarComponent,
    MonstruosComponent,
    DetailMonstruosComponent,
    ErrorComponent,
    FooterComponent,
    CriaturasComponent,
    MaterialesComponent,
    EquipamientoComponent,
    TesorosComponent,
    DetailCritaturasComponent,
    DetailEquipamientoComponent,
    DetailMaterialesComponent,
    DetailTesorosComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
