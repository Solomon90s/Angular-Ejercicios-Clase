import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {InicioComponent} from "./components/inicio/inicio.component";
import {DetailMonstruosComponent} from "./components/detail-monstruos/detail-monstruos.component";
import {MonstruosComponent} from "./components/monstruos/monstruos.component";
import {ErrorComponent} from "./components/error/error.component";
import {CriaturasComponent} from "./components/criaturas/criaturas.component";
import {MaterialesComponent} from "./components/materiales/materiales.component";
import {EquipamientoComponent} from "./components/equipamiento/equipamiento.component";
import {TesorosComponent} from "./components/tesoros/tesoros.component";
import {DetailMaterialesComponent} from "./components/detail-materiales/detail-materiales.component";
import {DetailEquipamientoComponent} from "./components/detail-equipamiento/detail-equipamiento.component";
import {DetailTesorosComponent} from "./components/detail-tesoros/detail-tesoros.component";
import {DetailCritaturasComponent} from "./components/detail-critaturas/detail-critaturas.component";

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/inicio'
  },
  {
    path: 'inicio',
    component: InicioComponent
  },
  {
    path: 'monstruos',
    component: MonstruosComponent
  },
  {
    path: 'criaturas',
    component: CriaturasComponent
  },
  {
    path: 'materiales',
    component: MaterialesComponent
  },
  {
    path: 'equipamiento',
    component: EquipamientoComponent
  },
  {
    path: 'tesoros',
    component: TesorosComponent
  },
  {
    path: 'detail-monstruos/:id',
    component: DetailMonstruosComponent
  },
  {
    path: 'detail-materiales/:id',
    component: DetailMaterialesComponent
  },
  {
    path: 'detail-equipamiento/:id',
    component: DetailEquipamientoComponent
  },
  {
    path: 'detail-tesoros/:id',
    component: DetailTesorosComponent
  },
  {
    path: 'detail-criaturas/:id',
    component: DetailCritaturasComponent
  },
  {
    path: '**',
    component: ErrorComponent,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
