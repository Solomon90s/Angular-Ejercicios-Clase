import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {ApiResultOneMonster, ApiResultZeldaAPI} from "../common/interfazZeldaMonstruos";

@Injectable({
  providedIn: 'root'
})
export class ZeldaService {

  private URI: string = "https://botw-compendium.herokuapp.com/api/v3/compendium";
  constructor( private http: HttpClient ) { }

  getMonstersZelda(): Observable<ApiResultZeldaAPI>{
    return this.http.get<ApiResultZeldaAPI>(this.URI+'/category'+'/monsters');
  }

  getMonsterZelda(id:number): Observable<ApiResultOneMonster>{
    return this.http.get<ApiResultOneMonster>(this.URI+'/entry/'+id);
  }

}
